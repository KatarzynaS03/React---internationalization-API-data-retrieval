import React from "react";
import {AppBar, Toolbar, Typography} from "@mui/material";


function Header(props) {
    const {classes} = props;

    return (<div>
        <AppBar position="static" style={{backgroundColor: "#0C056D"}}>
            <Toolbar>
                <Typography variant="h5" color="inherit">
                    React Internationalization with i18next
                </Typography>
            </Toolbar>
        </AppBar>
    </div>);
}


export default Header;
