import '../App.css';
import React, {Component} from "react";
import { withTranslation} from "react-i18next";
import CSVCzytajka from "./CSVCzytajka";

import Header from "./Header";
import {
    Grid,
    Paper,
    FormLabel,
    Radio,
    RadioGroup,
    FormControlLabel,
    FormControl, Container
} from "@mui/material";


const styles = theme => ({
    root: {
        display: "flex",
        justifyContent: "center"
    },
    formControl: {
        margin: theme.spacing.unit * 3
    },
    group: {
        margin: `${theme.spacing.unit}px 0`,
        flexDirection: "row"
    },
    container: {
        flexGrow: 1
    },
    paper: {
        padding: theme.spacing.unit * 2,
        textAlign: "center",
        color: theme.palette.text.secondary
    },
    topgrid: {
        marginTop: "10px",
        textAlign: "center",
        alignItems: "center",
        justifyContent: "center"
    }
});


class App extends Component {

    constructor(props) {
        super(props);
        this.state = {
            value: "en"
        };
    }

    handleChange = event => {
        // language selection handler
        let newlang = event.target.value;
        this.setState(prevState => ({value: newlang}));
        this.props.i18n.changeLanguage(newlang);
    };

    render() {
        const {t} = this.props;

        return (
            <div className="App">
                <Header/>
                <Container>
                    <Grid container spacing={24}>
                        <Grid item xs={2} sm={4} md={4}>
                            <Paper variant="outlined" square>
                                <FormControl component="fieldset">
                                    <FormLabel component="legend">
                                        {t("SelectLanguage")}
                                    </FormLabel>

                                    <RadioGroup
                                        aria-label="Gender"
                                        name="gender1"
                                        value={this.state.value}
                                        onChange={this.handleChange}
                                    >
                                        <FormControlLabel
                                            value="en"
                                            control={<Radio/>}
                                            label="English"
                                        />
                                        <FormControlLabel
                                            value="pl"
                                            control={<Radio/>}
                                            label="Polish"
                                        />
                                        <FormControlLabel
                                            value="ger"
                                            control={<Radio/>}
                                            label="German"
                                        />
                                    </RadioGroup>
                                </FormControl>
                            </Paper>
                        </Grid>
                    </Grid>

                    <Grid>
                    <CSVCzytajka></CSVCzytajka>
                    </Grid>
                </Container>
            </div>
        );
    }


}

export default (withTranslation("translations")(App));
