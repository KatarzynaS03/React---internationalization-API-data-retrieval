import React, {Component} from "react";
import "./style.css";
import FormikMaterialUI from "./FormikMaterialUI";
import axios from "axios";
import TestPlot3 from "./TestPlot3";
import CanvasJSReact from "../lib/canvasjs.react";
import {Grid} from "@mui/material";

let CanvasJSChart = CanvasJSReact.CanvasJSChart;

class CSVCzytajka extends Component{

    constructor(props) {
        super(props);
        this.state = {forecast: [], actual: [], lan: "en"}
        this.renderWykres = this.renderWykres.bind(this)
    }

    async renderWykres(when, lang) {
        const url = 'https://api.carbonintensity.org.uk/intensity/' + when.year + '-' + when.miesiac
            + '-' + (when.dzien - 1) + '/' + when.year + '-' + when.miesiac
            + '-' + when.dzien;

        const result = await axios.get(url)
        const time = []
        const time2 = []
        const data = result.data.data;

        data.map((row) => {
            const godz = new Date(row.to)
            time.push({x: godz, y : row.intensity.forecast})
            time2.push({x: godz, y : row.intensity.actual})
        });

        this.setState({forecast : time})
        this.setState({actual : time2})
        this.setState({lan : lang})
    }

    render () {

        return (
            <div>
                <Grid>
                <FormikMaterialUI onSubmit={this.renderWykres}/></Grid>
            <div className="container">

                    <TestPlot3 data = {this.state}></TestPlot3>

            </div>
            </div>
        );
    }
}


export default CSVCzytajka;