import React, {useState} from 'react';
import {useFormik} from 'formik';
import * as yup from "yup";
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import i18n from "../i18n";
import {Trans, useTranslation, withTranslation} from "react-i18next";
import {FormControl, FormControlLabel, FormLabel, Grid, Paper, Radio, RadioGroup} from "@mui/material";



const {faker} = require('@faker-js/faker');

function FormikMaterialUI({onSubmit}) {
    const [lan, setLan] = useState("en")
    const t = i18n.t

    const handleChange = event => {

        let newlang = event.target.value;
        setLan(newlang)
        i18n.changeLanguage(newlang)};
        
    const validationSchema = yup.object({
        dzien: yup
            .string(t('dzien'))
            .required(t('dzien2')),
        miesiac: yup
            .string(t('miesiac'))
            .required(t('miesiac2')),
        year: yup
            .number(t('rok'))
            .required(t('rok2'))
    });

    const formik = useFormik({
        initialValues: {
            dzien: '',
            miesiac: '',
            year: ''
        },
        validationSchema: validationSchema,
        onSubmit: (values,t) => {
            onSubmit(values, t);},
    });


    return (
        <div >
            <h1>{t("carbon")}</h1>
            <h2>{t("carbon2")}</h2>
            <form onSubmit={formik.handleSubmit} class="color">
                <TextField
                    fullWidth
                    id="dzien"
                    name="dzien"
                    label={t("dzien")}
                    value={formik.values.name}
                    onChange={formik.handleChange}
                    error={formik.touched.name && Boolean(formik.errors.name)}
                    helperText={formik.touched.name && formik.errors.name}
                    placeholder={t("dzien")}
                />
                <TextField
                    fullWidth
                    id="miesiac"
                    name="miesiac"
                    label={t("mieisac")}
                    value={formik.values.director}
                    onChange={formik.handleChange}
                    error={formik.touched.director && Boolean(formik.errors.director)}
                    helperText={formik.touched.director && formik.errors.director}
                    placeholder={t("mieisac")}
                />
                <TextField
                    fullWidth
                    id="year"
                    name="year"
                    label={t("rok")}
                    value={formik.values.year}
                    onChange={formik.handleChange}
                    error={formik.touched.year && Boolean(formik.errors.year)}
                    helperText={formik.touched.year && formik.errors.year}
                    placeholder={t("rok")}
                />
                <Button color="primary" variant="contained" fullWidth type="submit">
                    {t("zatwierdz")}
                </Button>
            </form>
        </div>
    );

};
export default FormikMaterialUI;


