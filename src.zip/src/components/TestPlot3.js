import React, {Component, useState} from 'react';
import CanvasJSReact from '../lib/canvasjs.react';
import {bottomNavigationActionClasses, Button, Grid} from "@mui/material";
import i18n from "../i18n";
import {Trans, useTranslation, withTranslation} from "react-i18next";

let CanvasJSChart = CanvasJSReact.CanvasJSChart;

class TestPlot3 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            value: "en"
        };
    }

    handleChange = event => {
        // language selection handler
        let newlang = event.target.value;
        this.setState(prevState => ({value: newlang}));
        this.props.i18n.changeLanguage(newlang);
    };
    
    render() {
        const t = i18n.t
        const {classes} = this.props;

        let chart = null;

        const options = {
            visible: false,
            legend:{
                fontSize: 17,
                fontFamily: "tamoha",
                fontColor: "Sienna"
            },
            zoomEnabled: true,
            width: 700,

            title: {
                text: t("carbon")
            },
            axisX: {
                valueFormatString:"HH:mm",
                labelAngle: -45,
                title: t("godzina"),
                interlacedColor: "#F0F8FF"
            },
            axisY: {
                interlacedColor: "#F0F8FF" ,
                valueFormatString: "####.##",
                title: t("emisja")
            },
            data: [{
                type: "line",
                dataPoints: this.props.data.forecast,
                legendText: t("prognoza"),
                showInLegend: true,
            },
                {
                    type: "line",
                    dataPoints: this.props.data.actual,
                    legendText: t("stan"),
                    showInLegend: true,
                }
            ]
        }
        return (
            <div>
                <Grid marginLeft={25}>
                <CanvasJSChart canvas="auto" options={options}/></Grid>
            </div>
        );
    }
}

export default TestPlot3;